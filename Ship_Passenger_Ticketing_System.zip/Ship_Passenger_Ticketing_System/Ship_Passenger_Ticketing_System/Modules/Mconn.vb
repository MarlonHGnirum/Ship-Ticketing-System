﻿Imports MySql.Data.MySqlClient
Module Module1
    Public con As New MySqlConnection("Server=localhost;username=root;password=;database=dbship;")
    Public con1 As New MySqlConnection("Server=localhost;username=root;password=;database=dbship;")
End Module

